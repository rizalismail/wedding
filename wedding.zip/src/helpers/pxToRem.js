function pxToRem(px) {
  const result = px / 14;
  return `${result}rem`;
}

export default pxToRem;
