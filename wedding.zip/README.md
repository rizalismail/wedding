# Dinda & Indra Wedding Website

![Gatsby Publish](https://github.com/idindrakusuma/thekusuma/workflows/Gatsby%20Publish/badge.svg) [![Netlify Status](https://api.netlify.com/api/v1/badges/4481a013-a72b-4ecf-939b-00b84c25dd89/deploy-status)](https://app.netlify.com/sites/thekusuma/deploys)

Features:
- Landing Page, with features like:
 - Countdown Timer
 - Live Button
 - Floating Music
 - Photo Gallery
 - Pre-wedding Video 
 - And more..
- also, this web-app has QR Guest Generator
- and Guest Tikcet Viewer

Tech Stack:
- GatsbyJs

Credits
- Original Landing Page Template (https://freehtml5.co/)
- Icon Assets (https://www.flaticon.com/packs/covid-protection-measures-5)

Thanks!
